
/**
 *
 * @author candidate 184521
 */
import java.util.Arrays;
import java.util.Random;

class FutoshikiPuzzle {

    String[][] grid;
    String[][] rowConstraint;
    String[][] columnConstraint;
    int axis;
    int limit;
    String gridString;

    FutoshikiPuzzle(int axis) {
        //all global variables are intialised
        this.axis = axis;
        grid = new String[axis][axis];
        rowConstraint = new String[axis][axis];
        columnConstraint = new String[axis][axis];
        limit = axis - 1;
    }

    public void setSquare(int posX, int posY, int value) {
        //set a position in the array to specific value
        grid[posY][posX] = Integer.toString(value);
    }

    public void setRowConstraint(int posX, int posY, String constraint) {
        //set a position in the array to specific constraint
        rowConstraint[posY][posX] = constraint;
    }

    public void setColumnConstraint(int posX, int posY, String constraint) {
        //set a position in the array to specific constraint
        columnConstraint[posY][posX] = constraint;
    }

    public void fillPuzzle() {
        //setting up for loops for the x and y indexes
        for (int y = 0; y <= limit; y++) {
            for (int x = 0; x <= limit; x++) {
                int z = getRandom(1, 9);
                int c = getRandom(1, axis);
                //create a constraint for the row and column
                generateRow(x, y);
                generateColumn(x, y);
                //If a value isn't inputted by setSquare its made a space
                if (grid[y][x] == null) {
                    grid[y][x] = " ";
                }
                //puts a line in if its the first square of a row
                if (x == 0 && z == 1) {
                    grid[y][x] = "\n ---     ---     ---     ---     --- \n" + "| " + Integer.toString(c) + " |" + rowConstraint[y][x];
                } else if (x == 0 && grid[y][x] != null) {
                    grid[y][x] = "\n ---     ---     ---     ---     --- \n" + "| " + grid[y][x] + " |" + rowConstraint[y][x];
                } //if its the last square in a row
                else if (x == limit && z == 1) {
                    grid[y][x] = "| " + Integer.toString(c) + " |" + "\n ---     ---     ---     ---     --- \n";
                } else if (x == limit && grid[y][x] != null) {
                    grid[y][x] = "| " + " " + " |" + "\n ---     ---     ---     ---     --- \n";
                }//1/9 chance that a square shall have a number in it
                else if (z == 1) {
                    grid[y][x] = "| " + Integer.toString(c) + " |" + rowConstraint[y][x];
                } else if (z != 1) {
                    grid[y][x] = "| " + grid[y][x] + " |" + rowConstraint[y][x];
                }//if its the bottom left square put a number in
                if (x == limit && y == 0) {
                    grid[limit][0] = Integer.toString(c);
                }
            }
            //loop to add in the column constraint
            for (int x = 0; x <= limit - 1; x++) {
                grid[x][4] = grid[x][4] + columnConstraint[y][x];
            }

        }
    }

    public String displayString() {
        //create the string from the array and return it
        gridString = (Arrays.deepToString(grid).replace(",", "").replace("[", "").replace("]", "").replace("< ", "<").replace("> ", ">").replace("0", " "));
        return gridString;
    }

    private int getRandom(int min, int max) {
        //function to get a value in a range
        Random r = new Random();
        int n = ((max - min) + 1) + min;
        return r.nextInt(n);
    }

    private void generateRow(int x, int y) {
        //create the row constraint
        int r = getRandom(1, 8);
        if (rowConstraint[y][x] == null) {
            if (r == 1) {
                rowConstraint[y][x] = " > ";
            } else if (r == 2) {
                rowConstraint[y][x] = " < ";
            } else {
                rowConstraint[y][x] = "  ";
            }
        }
    }

    private void generateColumn(int x, int y) {
        //create the column constraint
        int r = getRandom(1, 8);
        if (columnConstraint[y][x] == null) {
            if (r == 1) {
                columnConstraint[y][x] = "  ^     ";
            } else if (r == 2) {
                columnConstraint[y][x] = "  v     ";
            } else {
                columnConstraint[y][x] = "        ";
            }
        }
    }

    boolean checkGrid() {
        //function to check if there any empty spaces in the grid
        for (int y = 0; y <= limit; y++) {
            for (int x = 0; x <= limit; x++) {
                if (grid[x][y] == null) {
                    return false;
                }
            }
        }
        return true;
    }

    public static void main(String[] args) {
        //main function that calls the above function
        FutoshikiPuzzle fp = new FutoshikiPuzzle(5);
        fp.fillPuzzle();
        System.out.println(fp.displayString());
    }
}
