/**
 *
 * @author candidate 184521
 */

import org.junit.Test;
import static org.junit.Assert.*;

public class FutoshikiPuzzleTest {
    
    public FutoshikiPuzzleTest() {   
    }
    @Test
    public void FutoshikiPuzzleTest(){
        FutoshikiPuzzle fp1= new FutoshikiPuzzle(5);
        assertEquals(fp1.axis,5);
        FutoshikiPuzzle fp2= new FutoshikiPuzzle(10);
        assertEquals(fp2.axis,10);
        FutoshikiPuzzle fp3= new FutoshikiPuzzle(15);
        assertEquals(fp3.axis,15);
    }
    
    @Test
    public void setSquareTest(){
        FutoshikiPuzzle fp1= new FutoshikiPuzzle(5);
        fp1.setSquare(1,1,1);
        assertEquals(fp1.grid[1][1],"1");
        FutoshikiPuzzle fp2= new FutoshikiPuzzle(10);
        fp2.setSquare(1,9,3);
        assertEquals(fp2.grid[9][1],"3");
        FutoshikiPuzzle fp3= new FutoshikiPuzzle(5);
        fp3.setSquare(4,4,4);
        assertEquals(fp3.grid[4][4],"4");
    }
    
    @Test
    public void setRowConstraintTest(){
        FutoshikiPuzzle fp1= new FutoshikiPuzzle(5);
        fp1.setRowConstraint(1,1,"<");
        assertEquals(fp1.rowConstraint[1][1],"<");
        FutoshikiPuzzle fp2= new FutoshikiPuzzle(5);
        fp2.setRowConstraint(1,1,">");
        assertEquals(fp2.rowConstraint[1][1],">");
        FutoshikiPuzzle fp3= new FutoshikiPuzzle(5);
        fp3.setRowConstraint(1,1," ");
        assertEquals(fp3.rowConstraint[1][1]," ");
    }
    
    @Test
    public void setColumnConstraintTest(){
        FutoshikiPuzzle fp1= new FutoshikiPuzzle(5);
        fp1.setColumnConstraint(1,1,"^");
        assertEquals(fp1.columnConstraint[1][1],"^");
        FutoshikiPuzzle fp2= new FutoshikiPuzzle(5);
        fp2.setColumnConstraint(1,1,"v");
        assertEquals(fp2.columnConstraint[1][1],"v");
        FutoshikiPuzzle fp3= new FutoshikiPuzzle(5);
        fp3.setColumnConstraint(1,1," ");
        assertEquals(fp3.columnConstraint[1][1]," ");
    }
    
    @Test
    public void fillPuzzleTest(){
        FutoshikiPuzzle fp= new FutoshikiPuzzle(5);
        fp.fillPuzzle();
        assertEquals(fp.checkGrid(),true);
    }
    
    @Test
    public void displayStringTest(){
        String example="";
        FutoshikiPuzzle fp= new FutoshikiPuzzle(5);
        fp.fillPuzzle();
        String grid=fp.displayString();
        for (int x=0;x<=9;x++){
            grid=grid.replace(Integer.toString(x),"");
        }
        grid=grid.replace("<", "").replace(">","").replace("^","").replace("v","");
        for (int z=0;z<=4;z++){
            example=example+"\n ---     ---     ---     ---     --- \n";
            example=example+"|   |   "+"|   |   "+"|   |   "+"|   |   "+"|   |        ";
            example=example+"\n ---     ---     ---     ---     --- \n";
        }
        grid=grid.replace(" ","");
        example=example.replace(" ","");
        assertEquals(example,grid);
    }
}
